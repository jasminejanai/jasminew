/**
 * 
 */
package com.leapmotion.gestures;

import com.leapmotion.controller.WebBrowserController;
import com.leapmotion.leap.Controller;

/**
 * @author Quan Le
 * @version 1.0
 * @since 04-Dec-2014
 */
public class LeapEvents {

    public Controller controller;
    public GesturesHandler gesture;
    public WebBrowserController webCtrl;

    public LeapEvents() {
        controller = new Controller();
        gesture = new GesturesHandler();
    }

    /**
     * Start Leap Motion controller.
     */
    public void start() {
        controller.addListener(gesture);

        // Tell controller that application runs in the background
        controller.setPolicyFlags(Controller.PolicyFlag.POLICY_BACKGROUND_FRAMES);

        gesture.webCtrl = new WebBrowserController();

        while (true) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (!gesture.webCtrl.browserIsOpen()) {
                break;
            }
        }
    }

    /**
     * Stop Leap Motion controller.
     */
    public void stop() {
        controller.removeListener(gesture);
    }

}

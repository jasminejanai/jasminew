/**
 * 
 */
package com.leapmotion.gestures;

/**
 * @author Quan Le
 * 
 */
public class LeapMain {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        LeapEvents leap = new LeapEvents();

        leap.start();
        leap.stop();

    }

}

/**
 * 
 */
package com.leapmotion.controller;

import com.leapmotion.gestures.GesturesHandler;
import com.leapmotion.leap.Controller;

/**
 * @author Quan Le
 * @version 1.0
 * @since 04-Dec-2014
 */
public class LeapEvents {

    Controller controller;
    GesturesHandler listener;

    public LeapEvents() {
        // TODO Auto-generated constructor stub
        listener = new GesturesHandler();
    }

    public void stop() {
        controller.removeListener(listener);
    }

    public void start() {
        controller.addListener(listener);
    }

}
